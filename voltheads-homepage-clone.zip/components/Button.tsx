
import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary';
}

const Button: React.FC<ButtonProps> = ({ children, className = '', variant = 'primary', ...props }) => {
  const baseClasses = "px-6 py-3 font-bold rounded-md transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-v-dark inline-block text-center";
  
  const variantClasses = {
    primary: 'bg-v-gold text-v-dark hover:bg-yellow-300 focus:ring-v-gold',
    secondary: 'bg-transparent border-2 border-v-gold text-v-gold hover:bg-v-gold hover:text-v-dark focus:ring-v-gold',
  };

  return (
    <button className={`${baseClasses} ${variantClasses[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
};

export default Button;
