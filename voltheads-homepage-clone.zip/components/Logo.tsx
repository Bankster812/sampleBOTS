
import React from 'react';

const Logo: React.FC<{ className?: string }> = ({ className }) => (
  <svg width="150" height="40" viewBox="0 0 160 40" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <path d="M15.2222 0L0 40H8.88889L24.1111 0H15.2222Z" fill="#FFC700"/>
    <path d="M17.4445 19.3333L24.1112 11.5555L26.3334 21.1111L33.0001 13.3333L26.3334 40H21.7779L26.3334 21.1111L19.6668 28.8889L17.4445 19.3333Z" fill="#FFC700"/>
    <text x="45" y="30" fontFamily="Inter, sans-serif" fontSize="24" fontWeight="900" fill="#E0E0E0" letterSpacing="0.05em">
      VOLTHEADS
    </text>
  </svg>
);

export default Logo;
