
import React from 'react';
import { Link } from 'react-router-dom';
import Logo from './Logo';

const SocialIcon: React.FC<{ children: React.ReactNode; href: string; ariaLabel: string }> = ({ children, href, ariaLabel }) => (
    <a href={href} aria-label={ariaLabel} target="_blank" rel="noopener noreferrer" className="text-v-gray hover:text-v-gold transition-colors duration-300">
        {children}
    </a>
);


const Footer: React.FC = () => {
  return (
    <footer className="bg-v-dark-alt border-t border-gray-800">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <Link to="/">
                <Logo />
            </Link>
            <p className="text-v-gray text-sm">
              Voltheads GmbH - Ihr Partner für intelligente Ladeinfrastruktur und Energiemanagement.
            </p>
            <div className="flex space-x-4">
                <SocialIcon href="#" ariaLabel="LinkedIn">
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M19 3A2 2 0 0 1 21 5v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4s1.39.63 1.39 1.4v4.93h2.8zM6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69s-1.68.76-1.68 1.69c0 .92.75 1.68 1.68 1.68zm-1.39 9.94h2.79V9.95H5.49v8.55z"/></svg>
                </SocialIcon>
                 <SocialIcon href="#" ariaLabel="Xing">
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M18.18 18.18h-2.83l-1.8-3.22a.4.4 0 0 0-.6-.1L11.2 16H9.25l4.38-7.3L9.67 3h2.9l1.68 3c.1.2.2.4.3.5l.3-.5 1.68-3h2.9l-4.1 6.8 4.13 8.38zM6.22 3L3 8.3l3.22 5.38h2.83l-3.22-5.38L6.22 3z"/></svg>
                </SocialIcon>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-v-light-gray tracking-wider uppercase">Navigation</h3>
            <ul className="mt-4 space-y-2">
              <li><Link to="/leistungen" className="text-base text-v-gray hover:text-white">Leistungen</Link></li>
              <li><Link to="/ueber-uns" className="text-base text-v-gray hover:text-white">Über Uns</Link></li>
              <li><Link to="/partner" className="text-base text-v-gray hover:text-white">Partner</Link></li>
              <li><Link to="/karriere" className="text-base text-v-gray hover:text-white">Karriere</Link></li>
              <li><Link to="/kontakt" className="text-base text-v-gray hover:text-white">Kontakt</Link></li>
            </ul>
          </div>
           <div>
            <h3 className="text-sm font-semibold text-v-light-gray tracking-wider uppercase">Rechtliches</h3>
            <ul className="mt-4 space-y-2">
              <li><Link to="#" className="text-base text-v-gray hover:text-white">Impressum</Link></li>
              <li><Link to="#" className="text-base text-v-gray hover:text-white">Datenschutz</Link></li>
              <li><Link to="#" className="text-base text-v-gray hover:text-white">AGB</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-v-light-gray tracking-wider uppercase">Kontakt</h3>
            <ul className="mt-4 space-y-2 text-base text-v-gray">
              <li>Voltheads GmbH</li>
              <li>Musterstraße 1, 12345 Berlin</li>
              <li><a href="mailto:hallo@voltheads.de" className="hover:text-v-gold">hallo@voltheads.de</a></li>
              <li><a href="tel:+493012345678" className="hover:text-v-gold">+49 (0) 30 1234 5678</a></li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t border-gray-800 pt-8 text-center">
            <p className="text-base text-v-gray">&copy; {new Date().getFullYear()} Voltheads GmbH. Alle Rechte vorbehalten.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
