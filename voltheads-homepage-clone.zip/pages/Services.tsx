
import React from 'react';

const ServiceDetailCard: React.FC<{ title: string; description: string; imageUrl: string; reverse?: boolean }> = ({ title, description, imageUrl, reverse = false }) => {
    return (
        <div className={`flex flex-col md:flex-row items-center gap-8 md:gap-16 ${reverse ? 'md:flex-row-reverse' : ''}`}>
            <div className="md:w-1/2">
                <img src={imageUrl} alt={title} className="rounded-lg shadow-lg object-cover w-full h-80 aspect-video"/>
            </div>
            <div className="md:w-1/2">
                <h3 className="text-3xl font-bold text-v-gold mb-4">{title}</h3>
                <p className="text-v-light-gray leading-relaxed">{description}</p>
            </div>
        </div>
    );
};


const Services: React.FC = () => {
    const servicesData = [
        {
            title: "Ladeinfrastruktur",
            description: "Von der ersten Idee bis zur betriebsbereiten Ladesäule – wir sind Ihr kompetenter Partner. Wir analysieren Ihren Bedarf, planen die optimale Infrastruktur und kümmern uns um die fachgerechte Installation und Inbetriebnahme. Ob für Mitarbeiter, Kunden oder die eigene Fahrzeugflotte, wir bieten skalierbare AC- und DC-Ladelösungen.",
            imageUrl: "https://picsum.photos/800/600?random=1&grayscale"
        },
        {
            title: "Energiemanagement",
            description: "Eine intelligente Ladeinfrastruktur braucht ein intelligentes Energiemanagement. Wir integrieren Ihre Ladelösungen in Ihr bestehendes Energiesystem, optimieren Lastspitzen durch dynamisches Lastmanagement und ermöglichen die Nutzung von erneuerbaren Energien. So senken Sie Kosten und maximieren die Nachhaltigkeit.",
            imageUrl: "https://picsum.photos/800/600?random=2&grayscale"
        },
        {
            title: "Fördermittelberatung",
            description: "Die Investition in E-Mobilität wird staatlich gefördert. Doch der Dschungel an Programmen auf Bundes-, Landes- und Kommunalebene ist undurchsichtig. Unsere Experten finden die passenden Förderungen für Ihr Projekt, unterstützen Sie bei der Antragsstellung und sichern Ihnen die maximale finanzielle Unterstützung.",
            imageUrl: "https://picsum.photos/800/600?random=3&grayscale"
        },
        {
            title: "Technische Betriebsführung",
            description: "Damit Ihre Ladeinfrastruktur jederzeit zuverlässig funktioniert, bieten wir eine umfassende technische Betriebsführung. Wir übernehmen das Monitoring, die Wartung und den Support Ihrer Anlagen, führen Software-Updates durch und sorgen für eine reibungslose Abrechnung. So können Sie sich auf Ihr Kerngeschäft konzentrieren.",
            imageUrl: "https://picsum.photos/800/600?random=4&grayscale"
        }
    ];

    return (
        <div className="bg-v-dark">
            <header className="bg-v-dark-alt py-24 text-center">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <h1 className="text-4xl md:text-5xl font-black text-white">Unsere Leistungen</h1>
                    <p className="mt-4 text-xl text-v-gray max-w-3xl mx-auto">
                        Ein umfassendes Portfolio für den Erfolg Ihrer E-Mobilitätsstrategie.
                    </p>
                </div>
            </header>
            
            <main className="py-20">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="space-y-24">
                        {servicesData.map((service, index) => (
                            <ServiceDetailCard 
                                key={service.title}
                                title={service.title}
                                description={service.description}
                                imageUrl={service.imageUrl}
                                reverse={index % 2 !== 0}
                            />
                        ))}
                    </div>
                </div>
            </main>
        </div>
    );
};

export default Services;
