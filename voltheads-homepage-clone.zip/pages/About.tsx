
import React from 'react';

const TeamMemberCard: React.FC<{ name: string; role: string; imageUrl: string }> = ({ name, role, imageUrl }) => (
    <div className="text-center text-v-light-gray">
        <img className="mx-auto h-40 w-40 rounded-full object-cover grayscale" src={imageUrl} alt={name} />
        <h3 className="mt-6 text-base font-semibold leading-7 tracking-tight text-white">{name}</h3>
        <p className="text-sm leading-6 text-v-gold">{role}</p>
    </div>
);

const About: React.FC = () => {
    const teamMembers = [
        { name: 'Max Mustermann', role: 'CEO & Founder', imageUrl: 'https://picsum.photos/200/200?random=1&grayscale&face' },
        { name: 'Erika Mustermann', role: 'CTO & Co-Founder', imageUrl: 'https://picsum.photos/200/200?random=2&grayscale&face' },
        { name: 'John Doe', role: 'Head of Sales', imageUrl: 'https://picsum.photos/200/200?random=3&grayscale&face' },
        { name: 'Jane Doe', role: 'Head of Operations', imageUrl: 'https://picsum.photos/200/200?random=4&grayscale&face' },
    ];

    return (
        <div className="bg-v-dark">
            <header className="bg-v-dark-alt py-24 text-center">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <h1 className="text-4xl md:text-5xl font-black text-white">Über Uns</h1>
                    <p className="mt-4 text-xl text-v-gray max-w-3xl mx-auto">
                        Wir sind die treibende Kraft hinter der Ladeinfrastruktur von morgen.
                    </p>
                </div>
            </header>

            <section className="py-20">
                <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center">
                        <h2 className="text-3xl font-bold text-v-gold">Unsere Geschichte</h2>
                        <p className="mt-4 text-lg text-v-light-gray leading-relaxed">
                            Voltheads wurde aus der Überzeugung geboren, dass die Zukunft der Mobilität elektrisch ist – und dass der Übergang dorthin einfach, intelligent und für jeden zugänglich sein muss. Gegründet von einem Team aus Energieexperten, Ingenieuren und Visionären, haben wir uns zum Ziel gesetzt, die komplexen Herausforderungen der Ladeinfrastruktur zu lösen. Wir kombinieren tiefes technisches Know-how mit einer Leidenschaft für Innovation, um unseren Kunden nicht nur Produkte, sondern ganzheitliche, zukunftssichere Lösungen anzubieten.
                        </p>
                    </div>
                </div>
            </section>
            
            <section className="bg-v-dark-alt py-24 sm:py-32">
                <div className="mx-auto max-w-7xl px-6 lg:px-8">
                    <div className="mx-auto max-w-2xl lg:mx-0 text-center">
                        <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Unser Team</h2>
                        <p className="mt-6 text-lg leading-8 text-v-gray">
                            Die Köpfe hinter Voltheads – engagiert, erfahren und immer für Sie da.
                        </p>
                    </div>
                    <ul
                        role="list"
                        className="mx-auto mt-20 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 sm:grid-cols-2 lg:mx-0 lg:max-w-none lg:grid-cols-4"
                    >
                        {teamMembers.map((person) => (
                           <li key={person.name}>
                               <TeamMemberCard name={person.name} role={person.role} imageUrl={person.imageUrl} />
                           </li>
                        ))}
                    </ul>
                </div>
            </section>
        </div>
    );
};

export default About;
