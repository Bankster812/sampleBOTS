
import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';

const ChargingIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-v-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3.75 13.5l3.75-3.75m0 0h12.5m-12.5 0v12.5" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11.25 4.5l7.5 7.5-7.5 7.5" /></svg>;
const EnergyIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-v-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>;
const SubsidyIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-v-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" /></svg>;
const OperationsIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-v-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;

const ServiceCard: React.FC<{ icon: React.ReactNode; title: string; children: React.ReactNode }> = ({ icon, title, children }) => (
    <div className="bg-v-dark-alt p-8 rounded-lg text-center transform hover:-translate-y-2 transition-transform duration-300 h-full flex flex-col">
        <div className="flex justify-center mb-4">{icon}</div>
        <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
        <p className="text-v-gray flex-grow">{children}</p>
    </div>
);

const Home: React.FC = () => {
    return (
        <div>
            {/* Hero Section */}
            <section className="relative h-[80vh] min-h-[500px] flex items-center justify-center text-center text-white overflow-hidden">
                <div className="absolute inset-0 bg-black opacity-60 z-10"></div>
                <img src="https://picsum.photos/1920/1080?random=hero&grayscale&blur=2" alt="E-mobility background" className="absolute inset-0 w-full h-full object-cover"/>
                <div className="relative z-20 px-4 animate-fade-in-up">
                    <h1 className="text-4xl md:text-6xl font-black uppercase tracking-wider leading-tight">
                        Die Zukunft der <span className="text-v-gold">E-Mobilität</span> gestalten
                    </h1>
                    <p className="mt-4 text-lg md:text-xl max-w-3xl mx-auto text-v-light-gray">
                        Wir sind Ihr Full-Service-Partner für Ladeinfrastruktur, Energiemanagement und Fördermittelberatung.
                    </p>
                    <div className="mt-8">
                        <Link to="/leistungen">
                            <Button>Unsere Services entdecken</Button>
                        </Link>
                    </div>
                </div>
            </section>

            {/* Mission Section */}
            <section className="py-20 bg-v-dark">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                    <h2 className="text-3xl font-extrabold text-white sm:text-4xl">Unsere Mission</h2>
                    <p className="mt-4 text-xl text-v-gray max-w-4xl mx-auto">
                        Unsere Mission ist es, den Übergang zur Elektromobilität für Unternehmen und Privatpersonen so einfach und effizient wie möglich zu gestalten. Mit maßgeschneiderten Lösungen und umfassender Expertise schaffen wir nachhaltige Werte und treiben die Energiewende voran.
                    </p>
                </div>
            </section>

            {/* Services Section */}
            <section className="py-20 bg-v-dark-alt">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center">
                        <h2 className="text-3xl font-extrabold text-white sm:text-4xl">Unsere Services</h2>
                        <p className="mt-4 text-xl text-v-gray">Alles aus einer Hand für Ihren Erfolg.</p>
                    </div>
                    <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-4">
                        <ServiceCard icon={<ChargingIcon />} title="Ladeinfrastruktur">Planung, Installation und Wartung von hochmodernen Ladelösungen für jeden Anwendungsfall.</ServiceCard>
                        <ServiceCard icon={<EnergyIcon />} title="Energiemanagement">Intelligente Steuerung und Optimierung Ihrer Energieflüsse für maximale Effizienz.</ServiceCard>
                        <ServiceCard icon={<SubsidyIcon />} title="Fördermittelberatung">Wir navigieren Sie durch den Förderdschungel und sichern Ihnen maximale Zuschüsse.</ServiceCard>
                        <ServiceCard icon={<OperationsIcon />} title="Technische Betriebsführung">Zuverlässiger Betrieb und Monitoring Ihrer Anlagen für eine maximale Verfügbarkeit.</ServiceCard>
                    </div>
                </div>
            </section>

            {/* Partners Section */}
            <section className="py-20 bg-v-dark">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <h2 className="text-center text-3xl font-extrabold text-white">Starke Partner an unserer Seite</h2>
                    <div className="mt-12 flow-root">
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 items-center">
                            {[...Array(5)].map((_, i) => (
                                <div key={i} className="flex justify-center grayscale hover:grayscale-0 opacity-60 hover:opacity-100 transition-all duration-300">
                                    <img className="h-10" src={`https://picsum.photos/200/50?random=${i}&grayscale`} alt={`Partner Logo ${i + 1}`} />
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>
            
            {/* CTA Section */}
            <section className="bg-v-gold">
                <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8 lg:flex lg:items-center lg:justify-between">
                    <h2 className="text-3xl font-extrabold tracking-tight text-v-dark sm:text-4xl">
                        <span className="block">Bereit für die Zukunft?</span>
                        <span className="block text-black opacity-80">Starten Sie jetzt Ihr Projekt mit uns.</span>
                    </h2>
                    <div className="mt-8 flex lg:mt-0 lg:flex-shrink-0">
                        <Link to="/kontakt">
                            <Button variant="secondary" className="border-v-dark text-v-dark hover:bg-v-dark hover:text-white">
                                Kostenloses Erstgespräch
                            </Button>
                        </Link>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Home;
