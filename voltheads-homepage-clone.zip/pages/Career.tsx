
import React, { useState } from 'react';
import Button from '../components/Button';
import { Link } from 'react-router-dom';

const JobOpening: React.FC<{ title: string; location: string; type: string; children: React.ReactNode }> = ({ title, location, type, children }) => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="bg-v-dark-alt rounded-lg p-6">
            <div className="flex justify-between items-center cursor-pointer" onClick={() => setIsOpen(!isOpen)}>
                <div>
                    <h3 className="text-xl font-bold text-white">{title}</h3>
                    <p className="text-v-gray mt-1">{location} &middot; {type}</p>
                </div>
                <svg className={`w-6 h-6 text-v-gold transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
            </div>
            {isOpen && (
                <div className="mt-6 border-t border-gray-700 pt-6">
                    <div className="text-v-light-gray space-y-4">
                        {children}
                    </div>
                     <div className="mt-6">
                        <Link to="/kontakt">
                            <Button>Jetzt bewerben</Button>
                        </Link>
                    </div>
                </div>
            )}
        </div>
    );
};

const Career: React.FC = () => {
    return (
        <div className="bg-v-dark">
            <header className="bg-v-dark-alt py-24 text-center">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <h1 className="text-4xl md:text-5xl font-black text-white">Karriere bei Voltheads</h1>
                    <p className="mt-4 text-xl text-v-gray max-w-3xl mx-auto">
                        Gestalten Sie mit uns die Zukunft der Mobilität. Werden Sie Teil unseres Teams!
                    </p>
                </div>
            </header>

            <main className="py-20">
                <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                     <div className="text-center mb-16">
                         <h2 className="text-3xl font-bold text-v-gold">Warum Voltheads?</h2>
                         <p className="mt-4 text-lg text-v-light-gray leading-relaxed">
                            Wir sind ein dynamisches, wachsendes Unternehmen an der Spitze der E-Mobilitäts-Revolution. Bei uns finden Sie ein Umfeld, in dem Sie wirklich etwas bewegen können. Wir bieten flache Hierarchien, spannende Projekte, individuelle Entwicklungsmöglichkeiten und ein Team, das mit Leidenschaft bei der Sache ist.
                         </p>
                    </div>

                    <h2 className="text-2xl font-bold text-white mb-8 text-center">Offene Stellen</h2>
                    <div className="space-y-6">
                        <JobOpening title="Projektmanager Ladeinfrastruktur (m/w/d)" location="Berlin" type="Vollzeit">
                            <h4 className="font-semibold text-lg text-white mb-2">Ihre Aufgaben:</h4>
                            <ul className="list-disc list-inside space-y-1 text-v-gray mb-4">
                                <li>Planung und Steuerung von Kundenprojekten im Bereich Ladeinfrastruktur</li>
                                <li>Koordination von internen Teams und externen Dienstleistern</li>
                                <li>Qualitäts-, Kosten- und Terminverantwortung</li>
                                <li>Technische Beratung und Betreuung unserer Kunden</li>
                            </ul>
                            <h4 className="font-semibold text-lg text-white mb-2">Ihr Profil:</h4>
                             <ul className="list-disc list-inside space-y-1 text-v-gray">
                                <li>Abgeschlossenes Studium (Ingenieurwesen, Wirtschaftsingenieurwesen) oder vergleichbare Qualifikation</li>
                                <li>Erfahrung im Projektmanagement, idealerweise im Energie- oder E-Mobilitätssektor</li>
                                <li>Starke Kommunikationsfähigkeiten und Kundenorientierung</li>
                                <li>Begeisterung für neue Technologien</li>
                            </ul>
                        </JobOpening>
                        <JobOpening title="Elektroinstallateur für Ladesäulen (m/w/d)" location="Bundesweit" type="Vollzeit">
                            <h4 className="font-semibold text-lg text-white mb-2">Ihre Aufgaben:</h4>
                            <ul className="list-disc list-inside space-y-1 text-v-gray mb-4">
                                <li>Installation und Inbetriebnahme von AC- und DC-Ladesäulen</li>
                                <li>Wartung und Störungsbeseitigung</li>
                                <li>Durchführung von Prüfungen nach DGUV V3</li>
                                <li>Dokumentation der durchgeführten Arbeiten</li>
                            </ul>
                            <h4 className="font-semibold text-lg text-white mb-2">Ihr Profil:</h4>
                             <ul className="list-disc list-inside space-y-1 text-v-gray">
                                <li>Abgeschlossene Ausbildung als Elektroniker für Energie- und Gebäudetechnik oder vergleichbar</li>
                                <li>Erfahrung mit der Installation von Ladeinfrastruktur von Vorteil</li>
                                <li>Hohes Maß an Selbstständigkeit und Reisebereitschaft</li>
                                <li>Führerschein Klasse B</li>
                            </ul>
                        </JobOpening>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default Career;
