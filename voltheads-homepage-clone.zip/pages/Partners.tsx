
import React from 'react';

const PartnerCard: React.FC<{ name: string; description: string; logoUrl: string }> = ({ name, description, logoUrl }) => (
    <div className="bg-v-dark-alt rounded-lg p-6 flex flex-col items-center text-center transform hover:-translate-y-2 transition-transform duration-300 h-full">
        <div className="h-20 flex items-center justify-center mb-4">
            <img src={logoUrl} alt={`${name} logo`} className="max-h-12 grayscale hover:grayscale-0 transition-all duration-300" />
        </div>
        <h3 className="text-xl font-bold text-white mb-2">{name}</h3>
        <p className="text-v-gray flex-grow">{description}</p>
    </div>
);

const Partners: React.FC = () => {
    const partnerData = [
        { name: 'ChargePoint', description: 'Führender Anbieter von EV-Ladehardware und -netzwerken.', logoUrl: 'https://picsum.photos/200/50?random=10&grayscale' },
        { name: 'Tesla', description: 'Pionier der Elektromobilität und Energiespeicherung.', logoUrl: 'https://picsum.photos/200/50?random=11&grayscale' },
        { name: 'Siemens', description: 'Globaler Technologiekonzern mit Fokus auf Elektrifizierung.', logoUrl: 'https://picsum.photos/200/50?random=12&grayscale' },
        { name: 'ABB', description: 'Technologieführer bei DC-Schnellladelösungen.', logoUrl: 'https://picsum.photos/200/50?random=13&grayscale' },
        { name: 'EnBW', description: 'Einer der größten Energieversorger in Deutschland.', logoUrl: 'https://picsum.photos/200/50?random=14&grayscale' },
        { name: 'Sonnen', description: 'Spezialist für Heimspeicher und dezentrale Energielösungen.', logoUrl: 'https://picsum.photos/200/50?random=15&grayscale' },
    ];

    return (
        <div className="bg-v-dark">
            <header className="bg-v-dark-alt py-24 text-center">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <h1 className="text-4xl md:text-5xl font-black text-white">Unsere Partner</h1>
                    <p className="mt-4 text-xl text-v-gray max-w-3xl mx-auto">
                        Gemeinsam stärker: Wir setzen auf ein Netzwerk aus führenden Technologie- und Branchenpartnern.
                    </p>
                </div>
            </header>

            <main className="py-20">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                         <h2 className="text-3xl font-bold text-v-gold">Ein starkes Ökosystem</h2>
                         <p className="mt-4 text-lg text-v-light-gray leading-relaxed max-w-4xl mx-auto">
                            Erfolg in der Elektromobilität erfordert Zusammenarbeit. Deshalb pflegen wir enge Partnerschaften mit den besten Unternehmen der Branche. Von Hardware-Herstellern über Energieversorger bis hin zu Software-Spezialisten – unser Netzwerk ermöglicht es uns, Ihnen stets die beste und fortschrittlichste Lösung anzubieten.
                         </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                        {partnerData.map((partner) => (
                            <PartnerCard key={partner.name} {...partner} />
                        ))}
                    </div>
                </div>
            </main>
        </div>
    );
};

export default Partners;
